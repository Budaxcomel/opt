/* MeowRun Service Worker (cache + offline)
   NOTE: Bila update front-end, tukar CACHE name supaya client ambil versi baru.
*/
const CACHE = "meowrun-v5-20260101";
const ASSETS = [
  "/",
  "/index.html",
  "/app.css",
  "/app.js",
  "/manifest.json"
];

self.addEventListener("install", (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(ASSETS))
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    // buang cache lama supaya tak stuck loading dengan app.js lama
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

function isApiPath(pathname){
  return (
    pathname === "/config" ||
    pathname === "/me" ||
    pathname === "/profile" ||
    pathname === "/ledger" ||
    pathname.startsWith("/auth/") ||
    pathname.startsWith("/game/") ||
    pathname.startsWith("/rewards/") ||
    pathname.startsWith("/invite/") ||
    pathname.startsWith("/bank/") ||
    pathname.startsWith("/withdraws") ||
    pathname.startsWith("/admin/") ||
    pathname.startsWith("/api/") // legacy
  );
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Only handle same-origin
  if (url.origin !== location.origin) return;

  // Never cache API calls
  if (isApiPath(url.pathname)) return;

  // HTML navigation: network-first (fallback to cached index.html)
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req).catch(() => caches.match("/index.html"))
    );
    return;
  }

  // Static assets: cache-first, then update cache from network
  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;

      return fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((cache) => cache.put(req, copy));
        return res;
      });
    })
  );
});
